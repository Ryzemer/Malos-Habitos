# Definición de variables
x = 10
y = 5
z = x + y

# Definición de la función
def f(a, b):
    c = a * b
    return c

# Llamada a la función con los valores de x y z
resultado = f(x, z)

# Impresión del resultado
print(resultado)
